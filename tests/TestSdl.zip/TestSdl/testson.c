#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>

static const int largeur = 800;
static const int hauteur = 600;

int main(int argc, char **argv) {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
    Mix_Music *musiqueFond = Mix_LoadMUS("Leateq - Tokyo.mp3");
    SDL_Window *fenetre = SDL_CreateWindow("Test son", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, largeur, hauteur, SDL_WINDOW_OPENGL);
    SDL_Renderer *rendu = SDL_CreateRenderer(fenetre, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    SDL_SetRenderDrawColor(rendu, 255, 0, 0, 255);
    Mix_PlayMusic(musiqueFond, -1);

    SDL_Surface* icone = SDL_LoadBMP("Wankul.bmp");
    if (icone != NULL) {
        SDL_SetWindowIcon(fenetre, icone);
        SDL_FreeSurface(icone);
    } else {
        SDL_Log("Impossible de charger l'icône : %s", SDL_GetError());
    }

    TTF_Init();
    TTF_Font* police = TTF_OpenFont("ttf/Act_Of_Rejection.ttf", 24);

    int vieMax = 100;
    int vie = vieMax;
    SDL_Rect barreDeVie = {50, 50, 200, 30};
    SDL_Rect perteVie = {0, 0, 0, 0};

    int timer = 10;
    Uint32 dernierTemps = SDL_GetTicks();
    bool enCours = true;
    SDL_Event evenement;

    // Ajout pour le compte à rebours et "Fight"
    int compteARebours = 3; // 3 secondes pour le compte à rebours
    bool afficherFight = false;
    Uint32 tempsDebutCompteARebours = SDL_GetTicks();
    bool compteAReboursTermine = false;

    while(enCours) {
        Uint32 tempsCourant = SDL_GetTicks();
        Uint32 deltaTime = tempsCourant - dernierTemps;

        // Logique du compte à rebours
        if (!compteAReboursTermine) {
            if (compteARebours > 0 && (tempsCourant - tempsDebutCompteARebours) >= 1000) {
                compteARebours--;
                tempsDebutCompteARebours = tempsCourant; // Réinitialise le temps de début pour le prochain tick
            } else if (compteARebours == 0) {
                afficherFight = true;
                compteAReboursTermine = true;
                tempsDebutCompteARebours = tempsCourant; // Commence à mesurer les 2 secondes pour afficher "Fight"
            }
        } else if (afficherFight && (tempsCourant - tempsDebutCompteARebours) >= 2000) {
            // Après 2 secondes, arrête d'afficher "Fight" et commence le jeu normalement
            afficherFight = false;
        }

        while(SDL_PollEvent(&evenement)) {
            if(evenement.type == SDL_QUIT) {
                enCours = false;
            } else if (evenement.type == SDL_KEYDOWN) {
                if (evenement.key.keysym.sym == SDLK_ESCAPE) {
                    enCours = false;
                } else if (evenement.key.keysym.sym == SDLK_m) {
                    int perte = 5;
                    if (vie - perte < 0) perte = vie;
                    perteVie = (SDL_Rect){50 + 200 * vie / vieMax - 200 * perte / vieMax, 50, 200 * perte / vieMax, 30};
                    vie -= perte;
                    SDL_Delay(100);
                }
            }
        }
        if (!compteARebours && deltaTime >= 1000 && timer > 0) {
            timer--;
            dernierTemps = tempsCourant;
            if (timer <= 0) {
                fprintf(stderr, "Temps écoulé !\n");

            }
        }
 
    barreDeVie.w = 200 * vie / vieMax;

    SDL_SetRenderDrawColor(rendu, 0, 0, 0, 255);
    SDL_RenderClear(rendu);

    if (perteVie.w > 0) {
        SDL_SetRenderDrawColor(rendu, 255, 255, 255, 255);
        SDL_RenderFillRect(rendu, &perteVie);
        perteVie.w = 0;
    }

    if (vie > 80) {
        SDL_SetRenderDrawColor(rendu, 0, 255, 0, 255);
    } else if (vie > 60 && vie <= 80) {
        SDL_SetRenderDrawColor(rendu, 144, 238, 144, 255);
    } else if (vie > 40 && vie <= 60) {
        SDL_SetRenderDrawColor(rendu, 255, 255, 0, 255);
    } else if (vie > 20 && vie <= 40) {
        SDL_SetRenderDrawColor(rendu, 255, 165, 0, 255);
    } else {
        SDL_SetRenderDrawColor(rendu, 220, 20, 60, 255);
    }
    if(vie == 0)
    {
    	enCours = false ;
    }

    // Affichage de "Fight" si nécessaire
    if (afficherFight) {
        SDL_Color couleurTexte = {255, 255, 255};
        char texteFight[] = "Fight !";
        SDL_Surface* surfaceFight = TTF_RenderText_Solid(police, texteFight, couleurTexte);
        SDL_Texture* textureFight = SDL_CreateTextureFromSurface(rendu, surfaceFight);
        SDL_Rect rectFight = {largeur / 2 - surfaceFight->w / 2, hauteur / 2 - surfaceFight->h / 2, surfaceFight->w, surfaceFight->h};
        SDL_RenderCopy(rendu, textureFight, NULL, &rectFight);

        SDL_FreeSurface(surfaceFight);
        SDL_DestroyTexture(textureFight);
    }
    if (!compteAReboursTermine) {
            char texteCompteARebours[1024];
            snprintf(texteCompteARebours, sizeof(texteCompteARebours), "Combat dans : %d", compteARebours);
            SDL_Color couleurCompteARebours = {255, 255, 255};
            SDL_Surface* surfaceCompteARebours = TTF_RenderText_Solid(police, texteCompteARebours, couleurCompteARebours);
            SDL_Texture* textureCompteARebours = SDL_CreateTextureFromSurface(rendu, surfaceCompteARebours);
            SDL_Rect rectCompteARebours = {largeur / 2 - surfaceCompteARebours->w / 2, hauteur / 2 - surfaceCompteARebours->h / 2, surfaceCompteARebours->w, surfaceCompteARebours->h};
            SDL_RenderCopy(rendu, textureCompteARebours, NULL, &rectCompteARebours);
            SDL_FreeSurface(surfaceCompteARebours);
            SDL_DestroyTexture(textureCompteARebours);
        }

    SDL_Color couleurTexte = {255, 255, 255};
    char texteTimer[1024];
    snprintf(texteTimer, sizeof(texteTimer), "Temps restant: %d", timer);
    SDL_Surface* surfaceTexte = TTF_RenderText_Solid(police, texteTimer, couleurTexte);
    SDL_Texture* textureTexte = SDL_CreateTextureFromSurface(rendu, surfaceTexte);
    SDL_Rect rectTexte = {largeur / 2 - surfaceTexte->w / 2, 10, surfaceTexte->w, surfaceTexte->h};
    SDL_RenderCopy(rendu, textureTexte, NULL, &rectTexte);

    SDL_RenderFillRect(rendu, &barreDeVie);

    SDL_FreeSurface(surfaceTexte);
    SDL_DestroyTexture(textureTexte);

    SDL_RenderPresent(rendu);

    SDL_Delay(1000 / 60);
    }

	TTF_CloseFont(police);
	TTF_Quit();
	SDL_DestroyRenderer(rendu);
	SDL_DestroyWindow(fenetre);
	Mix_FreeMusic(musiqueFond);
	Mix_CloseAudio();
	SDL_Quit();

	return 0;
}

