gcc -o testson testson.c -lSDL2 -lSDL2_image -lSDL2_ttf -lSDL2_mixer

git add .
git commit -m "texte"
git push
